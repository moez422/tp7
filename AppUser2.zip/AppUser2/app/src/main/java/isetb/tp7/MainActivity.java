package isetb.tp7;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import isetb.tp7.Adapter.UserAdapter;
import isetb.tp7.Model.User;
import isetb.tp7.Utils.Apis;
import isetb.tp7.Utils.UserService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    private List<User> list = new ArrayList<>();
    private UserAdapter adapter;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Gérer les marges avec Edge-to-Edge
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialiser le RecyclerView
        recyclerView = findViewById(R.id.recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialiser l'adaptateur
        adapter = new UserAdapter(list);
        recyclerView.setAdapter(adapter);

        // Initialiser le bouton
        b1 = findViewById(R.id.b1);

        // Charger les utilisateurs au lancement
        loadUserList();

        // Lancer AddActivity avec startActivityForResult
        b1.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, AddActivity.class);
            startActivityForResult(i, 1);
        });
    }

    // Méthode pour charger la liste des utilisateurs
    private void loadUserList() {
        UserService apiService = Apis.getService();
        Call<List<User>> call = apiService.getAllUser();
        call.enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                if (response.isSuccessful()) {
                    list.clear();
                    list.addAll(response.body());
                    adapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(MainActivity.this, "Erreur lors du chargement des utilisateurs", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
                Log.e("MainActivity", "Erreur réseau : " + t.getMessage());
                Toast.makeText(MainActivity.this, "Erreur réseau : " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Méthode pour gérer le retour de AddActivity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            // Récupérer l'utilisateur ajouté depuis AddActivity
            User newUser = (User) data.getSerializableExtra("newUser");

            if (newUser != null) {
                // Ajouter directement l'utilisateur à la liste
                list.add(newUser);
                adapter.notifyItemInserted(list.size() - 1);
                recyclerView.scrollToPosition(list.size() - 1); // Aller à l'utilisateur ajouté
            }
        }
    }
}
