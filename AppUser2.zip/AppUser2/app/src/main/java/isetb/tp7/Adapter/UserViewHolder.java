package isetb.tp7.Adapter;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import isetb.tp7.Model.User;
import isetb.tp7.R;

public class UserViewHolder extends RecyclerView.ViewHolder {
    TextView e1,e2,e3,e4;
    public UserViewHolder(@NonNull View itemView) {
        super(itemView);
        e1=itemView.findViewById(R.id.fn);
        e2=itemView.findViewById(R.id.ln);
        e3=itemView.findViewById(R.id.age);
        e4=itemView.findViewById(R.id.email);

    }
    public void bind(User user){
        e1.setText(user.getFirstName());
        e2.setText(user.getLastName());
        e3.setText(String.valueOf(user.getAge()));
        e4.setText((user.getEmail()));

    }

}
