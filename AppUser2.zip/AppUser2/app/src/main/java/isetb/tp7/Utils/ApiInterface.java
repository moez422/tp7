package isetb.tp7.Utils;

import isetb.tp7.Model.User;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface ApiInterface {
    @POST("utilisateurs")
    @Headers("Content-Type: application/json")
    Call<Void> addUser(@Body User user);


}
