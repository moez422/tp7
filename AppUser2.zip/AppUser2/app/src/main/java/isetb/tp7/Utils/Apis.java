package isetb.tp7.Utils;

public class Apis {
    private static final String URL="http://10.0.2.2:8080";
    public static UserService getService(){
        return Client.getRetrofit(URL).create(UserService.class);
    }
}
