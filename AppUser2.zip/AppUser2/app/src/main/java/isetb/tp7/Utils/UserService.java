package isetb.tp7.Utils;

import java.util.List;

import isetb.tp7.Model.User;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface UserService {
    @GET("utilisateurs")
    Call<List<User>>getAllUser();

    @POST("utilisateurs")
    Call<Void> addUser(@Body User user);

}
