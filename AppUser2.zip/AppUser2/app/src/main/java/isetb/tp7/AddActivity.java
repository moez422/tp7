package isetb.tp7;
import android.util.Log;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

import isetb.tp7.Model.User;
import isetb.tp7.Utils.ApiInterface;
import isetb.tp7.Utils.Apis;
import isetb.tp7.Utils.UserService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddActivity extends AppCompatActivity {
    EditText e1,e2,e3,e4;
    Button b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        e1=findViewById(R.id.etFN);
        e2=findViewById(R.id.etLN);
        e3=findViewById(R.id.etAge);
        e4=findViewById(R.id.etEmail);
        b2=findViewById(R.id.b2);
b2.setOnClickListener(v -> addUsers());
    }

    private void addUsers() {
        String fn = e1.getText().toString();
        String ln = e2.getText().toString();
        String age = e3.getText().toString();
        String email = e4.getText().toString();

        if (fn.isEmpty() || ln.isEmpty() || age.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "Remplir les champs", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = new User(fn, ln, email, Integer.parseInt(age));
        UserService apiService = Apis.getService();
        Call<Void> call = apiService.addUser(user);
        call.enqueue(new Callback<Void>() {


            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Log.d("malek", "Utilisateur ajouté avec succès");

                    // Renvoyer l'utilisateur ajouté à MainActivity
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("newUser", (CharSequence) user);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                } else {
                    Log.e("malek", "Erreur : " + response.message());
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.e("malek", "Erreur réseau : " + t.getMessage());
            }

        });
    }

}
